﻿//Project Prolog
//Name: Kurt Jones
//CS 1400 Section 001
//Project: Lab 18
//Date: 10/01/16

// I declare that the following code was written by me or provided
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
//---------------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_18_KJ_V1
{
    //Create a Random Number Generator Object
    class Program
    {
        static void Main(string[] args)
        {
            //Ask the user if they want to play
            //Get users response. If 'y' call random number program
            //if 'n' print goodbye message and quit.
            //if something else ask user to put valid input

            //Random Number Generator program
            //Generate two random numbers between 1-6
            //if the two numbers are 6 and 6 display "You got Boxcars"
            //if the two numbers are 1 and 1 display "You rolled snake-eyes"
            //if something else display "you rolled" and the two numbers
            //Ask the user if they want to play again
            //if 'y' return to top
            //if 'n' print goodbye message and close
            //if something else ask user for valid input
            Console.ReadLine();
        }
    }
}
//question 1: For loop
//question 2: While Loop
