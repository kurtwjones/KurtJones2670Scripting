﻿//Project Prolog
//Name: Kurt Jones
//CS 1400 Section 001
//Project: Lab 8
//Date: 09/17/16

// I declare that the following code was written by me or provided
// by the instructor for this project. I understand that copying source
// code from any other source constitutes cheating, and that I will receive
// a zero on this project if I am found in violation of this policy.
//---------------------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_08_KJ_V1
{
    class Program
    {
        static void Main()
        {
            //ask user for the radius of the circle
            //Take radius and times by 2 to get side of square
            //Take side of square and times by 2 to get area of square
            //calculate area of circle with PI R Squared
            //subtract area of square from area of circle
            //output shaded area
        }
    }
}
